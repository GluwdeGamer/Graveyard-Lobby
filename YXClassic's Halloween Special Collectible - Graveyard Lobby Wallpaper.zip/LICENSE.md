# **License Information (LICENSE)**

#### **YXClassic's Halloween Special - Graveyard Lobby Wallpaper**



***Information***



**© 2025 YXClassic, GluwdeGamer and Other Copyright Holders. All Rights Reserved.** 



**All assets, arts, designs, etc. are the sole intellectual property of YXClassic, GluwdeGamer and its respective copyright holders. This work is protected under the international and federal copyright laws of United Arab Emirates and the copyright holders' respective countries and all applicable international treaties. Unauthorized duplication, distribution, modification, or public display of this original work, in whole or in part, is strictly prohibited. This prohibition extends to the digital reproduction, commercial exploitation, and creation of derivative works without the express written consent of the copyright holder. Any and all violations of this copyright will be pursued to the fullest extent of the law, resulting in civil and/or criminal penalties. By accessing, purchasing, or using this product, you acknowledge and agree to respect the copyright holder's rights and refrain from any infringing activities. For licensing inquiries or requests for permission, please contact YXClassic at** [**yxclassicyt.74789@outlook.com**](yxclassicyt.74789@outlook.com) **or GluwdeGamer at** [**gluwdegamer@gmail.com**](gluwdegamer@gmail.com)**. Email the same two contacts if you want to ask other copyright holders, and we'll forward it. This texture pack has been termed as "Content" and further termed as "Digital Art Work" as per Clause 3: Definitions under GluwdeGamer Code of Conduct (94240GG). You may use this wallpaper(s) for non-commercial purposes only.**

